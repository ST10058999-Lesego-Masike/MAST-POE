import React, { useState, useCallback, useEffect } from 'react';
import { Text, View, StyleSheet, TextInput, Button, ScrollView } from 'react-native';
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";//<!--(React Native, 2023.)-->
import { FlatList } from 'react-native';

const Tab = createBottomTabNavigator();//(IIE, 2023.)

const neutralBackgroundColor = "#F5F5F5";

const predefinedGenres = ["Fiction", "Non-fiction", "Science Fiction", "Mystery", "Romance", "Fantasy"];

function HomeScreen({ lastReadBook, allBooks }) {//<!--(React Native, 2023.)-->
  const [totalPagesRead, setTotalPagesRead] = useState(0);
  const [averagePages, setAveragePages] = useState(0);

  // Calculate total pages read and average pages
  const updateStatistics = () => {
    let total = 0;
    allBooks.forEach((book) => {
      total += book.pages;
    });
    setTotalPagesRead(total);
    if (allBooks.length > 0) {
      setAveragePages(total / allBooks.length);
    } else {
      setAveragePages(0); //<!--(React Native, 2023.)-->
    }
  };

  
  
  useEffect(() => {
    updateStatistics();
  }, [allBooks]);
//(IIE, 2023.)
  return (
    <ScrollView contentContainerStyle={styles.page}>
      <View style={[styles.container, { backgroundColor: neutralBackgroundColor }]}>
        <View style={styles.topBar}>
          <View style={styles.top}>
            <Text style={styles.title}>My Bookshelf</Text>
            <View style={styles.iconButtons}>
              <MaterialCommunityIcons name="magnify" color="black" size={20} />
              <MaterialCommunityIcons name="book" color="black" size={20} />
            </View>
          </View>
        </View>

        <View style={styles.sectionTitle}>
          <Text style={styles.titleText}>Last Book Read</Text>
        </View>
        <View style={styles.list}>
          <View style={styles.row}>
            <View style={styles.card}>
              <View style={styles.imageContainer}>
                <View style={styles.image}>
                  <Text style={styles.imageTitle}>Image of Book Cover</Text>
                  <View style={styles.tag}>
                    <Text style={styles.tagText}>Genre: {lastReadBook.genre}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.textContent}>
                <Text style={styles.cardTitle}>{lastReadBook.title}</Text>
                <Text style={styles.subtitle}>Author: {lastReadBook.author}</Text> 
                <View style={styles.iconButtons}>
                  <MaterialCommunityIcons name="pencil" color="black" size={20} />
                </View>
              </View>
            </View> 
          </View>
        </View> 
          
        <View style={styles.sectionTitle}>
          <Text style={styles.titleText}>Reading Statistics</Text>
          <Text style={styles.subtitleText}>Total Pages Read</Text>
        </View> 
        <View style={styles.list}>
          <View style={styles.row}>
            <View style={styles.metric}>
              <Text style={styles.titleText}>Total Pages Read</Text>
              <Text style={styles.data}>{totalPagesRead}</Text>
            </View>
          </View>
        </View>

        <View style={styles.sectionTitle}>
          <Text style={styles.titleText}>Reading Statistics</Text>
          <Text style={styles.subtitleText}>Average Pages per Book</Text>
        </View>
        <View style={styles.list}>
          <View style={styles.row}>
            <View style={styles.metric}>
              <Text style={styles.titleText}>Average Pages per Book</Text>
              <Text style={styles.data}>{averagePages.toFixed(2)}</Text>
            </View>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

function AddBook({ updateLastReadBook, allBooks, setAllBooks }) { //(IIE, 2023.)
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    genre: "",
    pages: 0,
  }); //<!--(React Native, 2023.)-->

  const handleNewBookSubmission = () => {
   

   
    
    updateLastReadBook(newBook);

    
    setAllBooks([...allBooks, newBook]);

    
    setNewBook({ title: "", author: "", genre: "", pages: 0 });
  };

  return (
    <View style={[styles.container, { backgroundColor: neutralBackgroundColor }]}>
      <View style={styles.sectionTitle}>
        <Text style={styles.titleText}>Add Books</Text>
      </View>
      <View style={styles.list}>
        <TextInput
          style={styles.input}
          placeholder="Title"
          value={newBook.title} //<!--(React Native, 2023.)-->
          onChangeText={(text) => setNewBook({ ...newBook, title: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Author"
          value={newBook.author}
          onChangeText={(text) => setNewBook({ ...newBook, author: text })}
        />
        <View style={styles.inputWithDropdown}>
          <TextInput
            style={styles.input}
            placeholder="Genre"
            value={newBook.genre}
            onChangeText={(text) => setNewBook({ ...newBook, genre: text })}
          />
          <Text style={styles.inputLabel}>Choose from: {predefinedGenres.join(', ')}</Text> 
        </View>
        <TextInput
          style={styles.input}
          placeholder="Pages Read"
          value={newBook.pages.toString()}
          onChangeText={(text) => setNewBook({ ...newBook, pages: parseInt(text, 10) })}
        />
        <Button
          title="Add Book" //(IIE, 2023.)
          onPress={handleNewBookSubmission}
        />
      </View>
    </View>
  );
}
function GenreScreen({ allBooks }) { //(IIE, 2023.)
  // Calculate the total number of books in each genre
  const genreCounts = {};
  allBooks.forEach((book) => {
    const genre = book.genre;
    genreCounts[genre] = (genreCounts[genre] || 0) + 1;
  });

  return (
    <View style={[styles.container, { backgroundColor: neutralBackgroundColor }]}>
      <View style={styles.sectionTitle}>
        <Text style={styles.titleText}>Genre Statistics</Text>
      </View>
      {predefinedGenres.map((genre) => (
        <View key={genre} style={styles.row}>
          <View style={styles.metric}> 
            <Text style={styles.titleText}>{genre}</Text>
            <Text style={styles.data}>{genreCounts[genre] || 0}</Text>
          </View>
        </View>
      ))}
    </View>
  );
}

function HistoryScreen({ allBooks }) { //(IIE, 2023.)
  return (
    <View style={[styles.container, { backgroundColor: neutralBackgroundColor }]}>
      <View style={styles.sectionTitle}>
        <Text style={styles.titleText}>Reading History</Text>
      </View>
      <FlatList
        data={allBooks}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <View style={styles.card}>
              <View style={styles.imageContainer}>
                <View style={styles.image}>
                  <Text style={styles.imageTitle}>Image of Book Cover</Text>
                  <View style={styles.tag}>
                    <Text style={styles.tagText}>Genre: {item.genre}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.textContent}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.subtitle}>Author: {item.author}</Text>
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({//<!--(W3Schools Online Wed Tutorials, 2017)-->
  container: {
    flex: 1,
    padding: 16,
  },
  topBar: {
    height: 72,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: 'black',
    fontSize: 20,
    fontWeight: '500',
  },
  iconButtons: {
    flexDirection: 'row',
  },
  sectionTitle: {
    paddingTop: 16,
    flexDirection: 'row', //<!--(W3Schools Online Wed Tutorials, 2017)-->
    marginBottom: 12,
  },
  titleText: {
    color: 'black',
    fontSize: 18,
    fontWeight: '500',
  },
  subtitleText: {
    color: 'rgba(0, 0, 0, 0.50)',
    fontSize: 12,
    fontWeight: '400',
  },
  list: {
    height: 432,
    padding: 12,
    flexDirection: 'column',
  },
  row: {
    flexDirection: 'column',
    gap: 8,
  },
  card: {
    flex: 1,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.10)',
    flexDirection: 'column',
  },
  imageContainer: {
    height: 336,
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  image: {
    width: 451,
    height: 336,
    position: 'relative',
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
  },
  imageTitle: {
    width: 419,
    height: 16,
    left: 16,
    top: 160,
    position: 'absolute',
    textAlign: 'center',
    color: 'black',
    fontSize: 16,
    fontWeight: '500',
  },
  tag: {
    padding: 4,
    left: 0,
    top: 0,
    position: 'absolute',
    backgroundColor: 'rgba(0, 0, 0, 0.05)', //<!--(W3Schools Online Wed Tutorials, 2017)-->
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tagText: {
    color: 'black',
    fontSize: 12,
    fontWeight: '500',
  },
  textContent: {
    height: 96,
    padding: 12,
    flexDirection: 'column',
    gap: 4,
  },
  cardTitle: {
    color: 'black',
    fontSize: 12,
    fontWeight: '400',
  },
  subtitle: {
    color: 'black',
    fontSize: 16,
    fontWeight: '500',
  },
  metric: {
    padding: 12,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.10)',
    flexDirection: 'column',
    gap: 4,
  },
  data: {
    color: 'black',
    fontSize: 20,
    fontWeight: '500',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    padding: 8,
  },
  inputWithDropdown: {
    flexDirection: 'column',
  },
  inputLabel: {
    fontSize: 12,
    color: 'rgba(0, 0, 0, 0.50)',
  },
});

export default function App() {
  const [lastReadBook, setLastReadBook] = useState({
    title: "",
    author: "",
    genre: "",
    pages: 0,
  });
  const [allBooks, setAllBooks] = useState([]);

  const updateLastReadBook = useCallback((newBook) => {
    setLastReadBook(newBook);
  }, []);
//<!--(React Native, 2023.)-->
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen
          name="Home"
          options={{ tabBarIcon: ({ color, size }) => ( //(IIE, 2023.)
            <MaterialCommunityIcons name="home" color={color} size={size} />
          )}}
        >
          {() => <HomeScreen lastReadBook={lastReadBook} allBooks={allBooks} />}
        </Tab.Screen>
        <Tab.Screen
          name="Add Book"
          options={{ tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="book" color={color} size={size} />
          )}}
        >
          {() => (
            <AddBook
              updateLastReadBook={updateLastReadBook}
              allBooks={allBooks}
              setAllBooks={setAllBooks}
            />
          )}
        </Tab.Screen>
        <Tab.Screen
          name="History"
          options={{ tabBarIcon: ({ color, size }) => ( //(IIE, 2023.)
            <MaterialCommunityIcons name="history" color={color} size={size} />
          )}}
        >
          {() => <HistoryScreen allBooks={allBooks} />}
        </Tab.Screen>
        <Tab.Screen
          name="Genres"
          options={{ tabBarIcon: ({ color, size }) => ( //(IIE, 2023.)
            <MaterialCommunityIcons name="tag" color={color} size={size} />
          )}}
        >
          {() => <GenreScreen allBooks={allBooks} />}
        </Tab.Screen>
      </Tab.Navigator>
    </NavigationContainer>
  );
}

//<!--W3schools.com.2017.W3schools Online WEb Tutorials. [online] Available at: <https://www.w3schools.com/>[Accessed 23 October 2023]-->
//<!--Setting up the development environment · React Native. (2023, August 29). Available at: <https://reactnative.dev/docs/environment-setup> [Accessed 20 October 2023]-->
//<!--The IIE 2023. Mobile App Scripting. Module Manual. The independent Institute of Education: Unpublished [Accessed 25 October 2023]-->